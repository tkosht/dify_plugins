from __future__ import annotations

import pytest

from app.openai_responses_provider.internal.payloads import build_responses_payload


def test_json_schema_requires_schema() -> None:
    with pytest.raises(ValueError):
        build_responses_payload(
            model="gpt-4.1-mini",
            responses_input=[],
            model_parameters={"response_format": "json_schema"},
            tools=None,
            stop=None,
            stream=False,
            user=None,
        )


def test_json_schema_payload_and_strict_bool() -> None:
    payload = build_responses_payload(
        model="gpt-4.1-mini",
        responses_input=[{"role": "user", "content": [{"type": "input_text", "text": "hi"}]}],
        model_parameters={
            "response_format": "json_schema",
            "json_schema": {"name": "answer", "schema": {"type": "object"}},
            "store": "false",
            "parallel_tool_calls": True,
        },
        tools=None,
        stop=["END"],
        stream=True,
        user="u1",
    )
    assert payload["text"]["format"]["type"] == "json_schema"
    assert payload["text"]["format"]["json_schema"]["name"] == "answer"
    assert payload["store"] is False
    assert payload["parallel_tool_calls"] is True
    assert payload["stop"] == ["END"]
    assert payload["stream"] is True


def test_invalid_strict_bool_in_payload_fails() -> None:
    with pytest.raises(ValueError):
        build_responses_payload(
            model="gpt-4.1-mini",
            responses_input=[],
            model_parameters={"store": "nope"},
            tools=None,
            stop=None,
            stream=False,
            user=None,
        )
