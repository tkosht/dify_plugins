from __future__ import annotations

import pytest

from app.openai_responses_provider.internal.credentials import (
    coerce_strict_bool,
    resolve_client_settings,
)


def test_coerce_strict_bool_accepts_bool_and_canonical_strings() -> None:
    assert coerce_strict_bool(True) is True
    assert coerce_strict_bool(False) is False
    assert coerce_strict_bool("true") is True
    assert coerce_strict_bool("FALSE") is False


def test_coerce_strict_bool_rejects_ambiguous_values() -> None:
    with pytest.raises(ValueError):
        coerce_strict_bool("1")
    with pytest.raises(ValueError):
        coerce_strict_bool(1)
    with pytest.raises(ValueError):
        coerce_strict_bool("yes")


def test_resolve_client_settings_requires_api_key() -> None:
    with pytest.raises(ValueError):
        resolve_client_settings({})


def test_resolve_client_settings_validates_timeout() -> None:
    with pytest.raises(ValueError):
        resolve_client_settings({"openai_api_key": "sk-test", "timeout": 0})

    settings = resolve_client_settings(
        {
            "openai_api_key": "sk-test",
            "openai_api_base": "https://example.invalid/v1",
            "openai_organization": "org-test",
            "timeout": "3.5",
        }
    )
    assert settings["api_key"] == "sk-test"
    assert settings["base_url"] == "https://example.invalid/v1"
    assert settings["organization"] == "org-test"
    assert settings["timeout"] == 3.5
