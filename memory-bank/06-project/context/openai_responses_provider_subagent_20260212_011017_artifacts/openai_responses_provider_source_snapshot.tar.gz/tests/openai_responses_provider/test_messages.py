from __future__ import annotations

from app.openai_responses_provider.internal.messages import to_responses_input


def test_to_responses_input_with_text_roles_and_tool() -> None:
    messages = [
        {"role": "system", "content": "rules"},
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
        {"role": "tool", "tool_call_id": "call-1", "content": "{\"ok\": true}"},
    ]

    converted = to_responses_input(messages)

    assert converted[0]["role"] == "system"
    assert converted[1]["content"][0]["text"] == "hello"
    assert converted[2]["content"][0]["type"] == "output_text"
    assert converted[3]["type"] == "function_call_output"
    assert converted[3]["call_id"] == "call-1"
