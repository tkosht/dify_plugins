from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PLUGIN_ROOT = ROOT / "app" / "openai_responses_provider"


def test_required_files_exist() -> None:
    required = [
        "manifest.yaml",
        "main.py",
        "provider/openai_responses_provider.py",
        "provider/openai_responses_provider.yaml",
        "models/llm/llm.py",
        "internal/messages.py",
        "internal/payloads.py",
        "internal/credentials.py",
        "internal/errors.py",
        "README.md",
        "PRIVACY.md",
        ".env.example",
        "requirements.txt",
        "icon.svg",
    ]
    for rel in required:
        assert (PLUGIN_ROOT / rel).exists(), rel


def test_runtime_entrypoint_and_manifest_refs() -> None:
    main_text = (PLUGIN_ROOT / "main.py").read_text(encoding="utf-8")
    assert "Plugin(DifyPluginEnv" in main_text

    manifest = (PLUGIN_ROOT / "manifest.yaml").read_text(encoding="utf-8")
    assert "provider/openai_responses_provider.yaml" in manifest

    provider_yaml = (PLUGIN_ROOT / "provider" / "openai_responses_provider.yaml").read_text(
        encoding="utf-8"
    )
    assert "provider_source: provider/openai_responses_provider.py" in provider_yaml
    assert "models/llm/llm.py" in provider_yaml
