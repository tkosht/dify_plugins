from __future__ import annotations

from types import SimpleNamespace

from app.openai_responses_provider.models.llm.llm import (
    OpenaiResponsesProviderLargeLanguageModel,
)


class _FakeResponses:
    def __init__(self, *, stream_events, non_stream_response):
        self._stream_events = stream_events
        self._non_stream_response = non_stream_response

    def create(self, **kwargs):
        if kwargs.get("stream"):
            return list(self._stream_events)
        return self._non_stream_response


class _FakeClient:
    def __init__(self, *, stream_events, non_stream_response):
        self.responses = _FakeResponses(
            stream_events=stream_events,
            non_stream_response=non_stream_response,
        )


def _build_model() -> OpenaiResponsesProviderLargeLanguageModel:
    try:
        return OpenaiResponsesProviderLargeLanguageModel([])
    except TypeError:
        return OpenaiResponsesProviderLargeLanguageModel()


def test_chunk_helper_sets_delta_and_finish_reason() -> None:
    model = _build_model()
    chunk = model._chunk(model="gpt-4.1-mini", text="hello", finish_reason="stop")
    assert chunk.model == "gpt-4.1-mini"
    assert chunk.delta.message.content == "hello"
    assert chunk.delta.finish_reason == "stop"


def test_invoke_non_stream_returns_result(monkeypatch) -> None:
    model = _build_model()

    non_stream_response = SimpleNamespace(
        output_text="hello world",
        usage=SimpleNamespace(input_tokens=3, output_tokens=2, total_tokens=5),
    )
    fake_client = _FakeClient(stream_events=[], non_stream_response=non_stream_response)
    monkeypatch.setattr(model, "_new_client", lambda credentials: fake_client)

    result = model._invoke(
        model="gpt-4.1-mini",
        credentials={"openai_api_key": "sk-test"},
        prompt_messages=[{"role": "user", "content": "hello"}],
        model_parameters={},
        stream=False,
    )

    assert result.model == "gpt-4.1-mini"
    assert result.message.content == "hello world"
    assert result.usage.total_tokens == 5


def test_invoke_stream_returns_chunks(monkeypatch) -> None:
    model = _build_model()

    stream_events = [
        {"type": "response.output_text.delta", "delta": "hel"},
        {"type": "response.output_text.delta", "delta": "lo"},
        {
            "type": "response.completed",
            "response": {
                "usage": {"input_tokens": 4, "output_tokens": 2, "total_tokens": 6}
            },
        },
    ]
    fake_client = _FakeClient(stream_events=stream_events, non_stream_response=None)
    monkeypatch.setattr(model, "_new_client", lambda credentials: fake_client)

    chunks = list(
        model._invoke(
            model="gpt-4.1-mini",
            credentials={"openai_api_key": "sk-test"},
            prompt_messages=[{"role": "user", "content": "hello"}],
            model_parameters={},
            stream=True,
        )
    )

    assert chunks[0].delta.message.content == "hel"
    assert chunks[1].delta.message.content == "lo"
    assert chunks[-1].delta.finish_reason == "stop"
    assert chunks[-1].delta.usage.total_tokens == 6
