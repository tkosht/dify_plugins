from __future__ import annotations

from collections.abc import Mapping
from typing import Any

DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_TIMEOUT = 120.0


def coerce_strict_bool(value: Any, field_name: str = "value") -> bool:
    """Coerce booleans strictly, rejecting ambiguous values."""
    if isinstance(value, bool):
        return value

    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"true", "false"}:
            return lowered == "true"

    raise ValueError(f"{field_name} must be a boolean literal (true/false)")


def get_required_string(credentials: Mapping[str, Any], key: str) -> str:
    value = credentials.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"Missing required credential: {key}")
    return value.strip()


def get_optional_string(credentials: Mapping[str, Any], key: str) -> str | None:
    value = credentials.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"Credential {key} must be a string")
    value = value.strip()
    return value or None


def resolve_client_settings(credentials: Mapping[str, Any]) -> dict[str, Any]:
    api_key = get_required_string(credentials, "openai_api_key")
    base_url = get_optional_string(credentials, "openai_api_base") or DEFAULT_BASE_URL
    organization = get_optional_string(credentials, "openai_organization")

    timeout_value = credentials.get("timeout")
    timeout = DEFAULT_TIMEOUT
    if timeout_value is not None:
        try:
            timeout = float(timeout_value)
        except (TypeError, ValueError) as exc:
            raise ValueError("timeout must be a positive number") from exc
        if timeout <= 0:
            raise ValueError("timeout must be a positive number")

    settings: dict[str, Any] = {
        "api_key": api_key,
        "base_url": base_url,
        "timeout": timeout,
    }
    if organization:
        settings["organization"] = organization
    return settings


def default_validation_model(credentials: Mapping[str, Any]) -> str:
    value = credentials.get("model")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return "gpt-4.1-mini"
