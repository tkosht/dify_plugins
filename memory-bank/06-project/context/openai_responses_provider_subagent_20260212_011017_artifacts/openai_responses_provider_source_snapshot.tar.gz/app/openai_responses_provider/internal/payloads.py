from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .credentials import coerce_strict_bool
from .errors import ResponseFormatValidationError

_SUPPORTED_RESPONSE_FORMATS = {"text", "json_object", "json_schema"}


def _extract_response_format(model_parameters: Mapping[str, Any]) -> dict[str, Any] | None:
    response_format = model_parameters.get("response_format")
    if response_format is None:
        return None

    if isinstance(response_format, str):
        value = response_format.strip().lower()
        if value not in _SUPPORTED_RESPONSE_FORMATS:
            raise ResponseFormatValidationError(
                f"Unsupported response_format: {response_format}"
            )

        if value == "json_schema":
            schema = model_parameters.get("json_schema")
            if not isinstance(schema, Mapping) or not schema:
                raise ResponseFormatValidationError(
                    "response_format=json_schema requires json_schema"
                )
            return {"type": "json_schema", "json_schema": dict(schema)}

        return {"type": value}

    if isinstance(response_format, Mapping):
        format_type = str(response_format.get("type", "")).strip().lower()
        if format_type not in _SUPPORTED_RESPONSE_FORMATS:
            raise ResponseFormatValidationError(
                f"Unsupported response_format: {format_type}"
            )
        result = dict(response_format)
        if format_type == "json_schema":
            schema = result.get("json_schema")
            if not isinstance(schema, Mapping) or not schema:
                raise ResponseFormatValidationError(
                    "response_format=json_schema requires json_schema"
                )
        return result

    raise ResponseFormatValidationError("response_format must be string or object")


def _tool_payload(tools: list[Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for tool in tools:
        name = getattr(tool, "name", None)
        description = getattr(tool, "description", "")
        parameters = getattr(tool, "parameters", {})
        if not name:
            continue
        if not isinstance(parameters, Mapping):
            raise ValueError("Tool parameters must be a mapping")
        result.append(
            {
                "type": "function",
                "name": str(name),
                "description": str(description),
                "parameters": dict(parameters),
            }
        )
    return result


def build_responses_payload(
    *,
    model: str,
    responses_input: list[dict[str, Any]],
    model_parameters: Mapping[str, Any],
    tools: list[Any] | None,
    stop: list[str] | None,
    stream: bool,
    user: str | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model,
        "input": responses_input,
        "stream": bool(stream),
    }

    if user:
        payload["user"] = user

    if stop:
        payload["stop"] = stop

    for source_name, target_name in (
        ("temperature", "temperature"),
        ("top_p", "top_p"),
        ("presence_penalty", "presence_penalty"),
        ("frequency_penalty", "frequency_penalty"),
        ("max_tokens", "max_output_tokens"),
    ):
        value = model_parameters.get(source_name)
        if value is not None:
            payload[target_name] = value

    response_format = _extract_response_format(model_parameters)
    if response_format:
        payload["text"] = {"format": response_format}

    if tools:
        payload["tools"] = _tool_payload(tools)

    if "parallel_tool_calls" in model_parameters:
        payload["parallel_tool_calls"] = coerce_strict_bool(
            model_parameters["parallel_tool_calls"], "parallel_tool_calls"
        )

    if "store" in model_parameters:
        payload["store"] = coerce_strict_bool(model_parameters["store"], "store")

    return payload
