from __future__ import annotations

from .sdk import (
    InvokeAuthorizationError,
    InvokeBadRequestError,
    InvokeConnectionError,
    InvokeRateLimitError,
    InvokeServerUnavailableError,
)


class ResponseFormatValidationError(ValueError):
    """Raised when response_format settings are invalid."""


def resolve_invoke_error_mapping() -> dict[type[Exception], list[type[Exception]]]:
    """Map provider-specific errors into Dify unified invoke errors."""
    mapping: dict[type[Exception], list[type[Exception]]] = {
        InvokeConnectionError: [],
        InvokeServerUnavailableError: [],
        InvokeRateLimitError: [],
        InvokeAuthorizationError: [],
        InvokeBadRequestError: [ResponseFormatValidationError, ValueError],
    }

    try:
        from openai import APIConnectionError, APIError, AuthenticationError, BadRequestError, RateLimitError
    except Exception:
        return mapping

    mapping[InvokeConnectionError].append(APIConnectionError)
    mapping[InvokeServerUnavailableError].append(APIError)
    mapping[InvokeRateLimitError].append(RateLimitError)
    mapping[InvokeAuthorizationError].append(AuthenticationError)
    mapping[InvokeBadRequestError].append(BadRequestError)
    return mapping
