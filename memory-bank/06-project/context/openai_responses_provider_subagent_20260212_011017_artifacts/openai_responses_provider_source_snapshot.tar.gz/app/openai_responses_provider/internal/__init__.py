"""Internal helpers for openai_responses_provider."""
