from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any

try:
    from dify_plugin import LargeLanguageModel, ModelProvider
    from dify_plugin.entities import I18nObject
    from dify_plugin.entities.model import AIModelEntity, FetchFrom, ModelType
    from dify_plugin.entities.model.llm import (
        LLMResult,
        LLMResultChunk,
        LLMResultChunkDelta,
        LLMUsage,
    )
    from dify_plugin.entities.model.message import (
        AssistantPromptMessage,
        PromptMessage,
        PromptMessageTool,
    )
    from dify_plugin.errors.model import (
        CredentialsValidateFailedError,
        InvokeAuthorizationError,
        InvokeBadRequestError,
        InvokeConnectionError,
        InvokeRateLimitError,
        InvokeServerUnavailableError,
    )
except Exception:  # pragma: no cover - fallback only used without SDK

    class ModelType(str, Enum):
        LLM = "llm"

    class FetchFrom(str, Enum):
        CUSTOMIZABLE_MODEL = "customizable-model"

    @dataclass
    class I18nObject:
        en_US: str = ""
        zh_Hans: str = ""
        ja_JP: str = ""
        pt_BR: str = ""

    @dataclass
    class AIModelEntity:
        model: str
        label: I18nObject
        model_type: ModelType
        features: list[str]
        fetch_from: FetchFrom
        model_properties: dict[str, Any]
        parameter_rules: list[dict[str, Any]]

    @dataclass
    class PromptMessage:
        role: Any
        content: Any = None

        def get_text_content(self) -> str:
            if isinstance(self.content, str):
                return self.content
            return ""

    @dataclass
    class PromptMessageTool:
        name: str
        description: str = ""
        parameters: dict[str, Any] = field(default_factory=dict)

    @dataclass
    class AssistantPromptMessage(PromptMessage):
        tool_calls: list[Any] = field(default_factory=list)

        def __init__(self, content: Any = "", tool_calls: list[Any] | None = None):
            self.role = "assistant"
            self.content = content
            self.tool_calls = tool_calls or []

    @dataclass
    class LLMUsage:
        prompt_tokens: int = 0
        prompt_unit_price: Decimal = Decimal("0")
        prompt_price_unit: Decimal = Decimal("0")
        prompt_price: Decimal = Decimal("0")
        completion_tokens: int = 0
        completion_unit_price: Decimal = Decimal("0")
        completion_price_unit: Decimal = Decimal("0")
        completion_price: Decimal = Decimal("0")
        total_tokens: int = 0
        total_price: Decimal = Decimal("0")
        currency: str = "USD"
        latency: float = 0.0

    @dataclass
    class LLMResultChunkDelta:
        index: int
        message: AssistantPromptMessage
        usage: LLMUsage | None = None
        finish_reason: str | None = None

    @dataclass
    class LLMResultChunk:
        model: str
        delta: LLMResultChunkDelta
        prompt_messages: list[Any] = field(default_factory=list)
        system_fingerprint: str | None = None

    @dataclass
    class LLMResult:
        model: str
        message: AssistantPromptMessage
        usage: LLMUsage
        prompt_messages: list[Any] = field(default_factory=list)
        system_fingerprint: str | None = None

    class CredentialsValidateFailedError(Exception):
        pass

    class InvokeConnectionError(Exception):
        pass

    class InvokeServerUnavailableError(Exception):
        pass

    class InvokeRateLimitError(Exception):
        pass

    class InvokeAuthorizationError(Exception):
        pass

    class InvokeBadRequestError(Exception):
        pass

    class LargeLanguageModel:
        def _transform_invoke_error(self, error: Exception) -> Exception:
            return error

        def _get_num_tokens_by_gpt2(self, text: str) -> int:
            return len(text)

    class ModelProvider:
        def get_provider_schema(self):
            return type("Schema", (), {"provider": "openai_responses_provider"})()

        def get_model_instance(self, _model_type: ModelType):
            raise NotImplementedError("Model factory is not available in fallback mode")
