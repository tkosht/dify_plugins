from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from typing import Any


def _enum_or_value(value: Any) -> str:
    if hasattr(value, "value"):
        candidate = getattr(value, "value")
        if isinstance(candidate, str):
            return candidate
    if isinstance(value, str):
        return value
    return str(value)


def _extract_role(message: Any) -> str:
    if isinstance(message, Mapping):
        return _enum_or_value(message.get("role", "user"))
    return _enum_or_value(getattr(message, "role", "user"))


def _extract_content(message: Any) -> Any:
    if isinstance(message, Mapping):
        return message.get("content")
    return getattr(message, "content", None)


def _extract_tool_call_id(message: Any) -> str | None:
    if isinstance(message, Mapping):
        value = message.get("tool_call_id")
    else:
        value = getattr(message, "tool_call_id", None)
    if not value:
        return None
    return str(value)


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, Mapping):
        if "text" in value:
            return str(value["text"])
        if "data" in value:
            return str(value["data"])
    if hasattr(value, "data"):
        return str(getattr(value, "data"))
    return str(value)


def _convert_content(content: Any, role: str) -> list[dict[str, Any]]:
    if isinstance(content, str):
        msg_type = "output_text" if role == "assistant" else "input_text"
        return [{"type": msg_type, "text": content}]

    if content is None:
        return []

    if not isinstance(content, Iterable) or isinstance(content, (bytes, bytearray)):
        msg_type = "output_text" if role == "assistant" else "input_text"
        return [{"type": msg_type, "text": _as_text(content)}]

    result: list[dict[str, Any]] = []
    for item in content:
        item_type = ""
        if isinstance(item, Mapping):
            item_type = _enum_or_value(item.get("type", ""))
        elif hasattr(item, "type"):
            item_type = _enum_or_value(getattr(item, "type"))

        if item_type in {"text", "input_text", "output_text"}:
            result.append({"type": "input_text", "text": _as_text(item)})
            continue

        if item_type == "image":
            image_url = ""
            if isinstance(item, Mapping):
                image_url = str(item.get("url") or item.get("data") or "")
            else:
                image_url = str(getattr(item, "url", "") or getattr(item, "data", ""))
            if image_url:
                result.append({"type": "input_image", "image_url": image_url})
            continue

        result.append({"type": "input_text", "text": _as_text(item)})

    return result


def to_responses_input(prompt_messages: list[Any]) -> list[dict[str, Any]]:
    """Convert Dify prompt messages into Responses API input records."""
    items: list[dict[str, Any]] = []

    for message in prompt_messages:
        role = _extract_role(message)
        content = _extract_content(message)

        if role == "tool":
            tool_call_id = _extract_tool_call_id(message)
            items.append(
                {
                    "type": "function_call_output",
                    "call_id": tool_call_id or "tool-call",
                    "output": _as_text(content),
                }
            )
            continue

        normalized_role = role if role in {"system", "developer", "assistant", "user"} else "user"
        items.append(
            {
                "role": normalized_role,
                "content": _convert_content(content, normalized_role),
            }
        )

    return items


def prompt_messages_to_text(prompt_messages: list[Any]) -> str:
    lines: list[str] = []
    for message in prompt_messages:
        role = _extract_role(message)
        content = _extract_content(message)
        lines.append(f"{role}: {_as_text(content)}")
    return "\n".join(lines)


def safe_json_dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=True, separators=(",", ":"), default=str)
