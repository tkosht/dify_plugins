from __future__ import annotations

import logging
from collections.abc import Generator, Iterable, Mapping
from decimal import Decimal
from typing import Any

from ...internal.credentials import resolve_client_settings
from ...internal.errors import resolve_invoke_error_mapping
from ...internal.messages import prompt_messages_to_text, safe_json_dumps, to_responses_input
from ...internal.payloads import build_responses_payload
from ...internal.sdk import (
    AIModelEntity,
    AssistantPromptMessage,
    CredentialsValidateFailedError,
    FetchFrom,
    I18nObject,
    LLMResult,
    LLMResultChunk,
    LLMResultChunkDelta,
    LLMUsage,
    LargeLanguageModel,
    ModelType,
    PromptMessage,
    PromptMessageTool,
)

logger = logging.getLogger(__name__)


class OpenaiResponsesProviderLargeLanguageModel(LargeLanguageModel):
    """LLM provider implementation for OpenAI Responses API."""

    @property
    def _invoke_error_mapping(self) -> dict[type[Exception], list[type[Exception]]]:
        return resolve_invoke_error_mapping()

    def _new_client(self, credentials: Mapping[str, Any]):
        try:
            from openai import OpenAI
        except Exception as exc:  # pragma: no cover - import error path
            raise RuntimeError("openai package is required") from exc

        settings = resolve_client_settings(credentials)
        return OpenAI(**settings)

    def _invoke(
        self,
        model: str,
        credentials: dict,
        prompt_messages: list[PromptMessage],
        model_parameters: dict,
        tools: list[PromptMessageTool] | None = None,
        stop: list[str] | None = None,
        stream: bool = True,
        user: str | None = None,
    ) -> LLMResult | Generator[LLMResultChunk, None, None]:
        try:
            responses_input = to_responses_input(prompt_messages)
            payload = build_responses_payload(
                model=model,
                responses_input=responses_input,
                model_parameters=model_parameters,
                tools=tools,
                stop=stop,
                stream=stream,
                user=user,
            )

            client = self._new_client(credentials)
            response = client.responses.create(**payload)

            if stream:
                return self._stream_response(
                    model=model,
                    response_stream=response,
                )

            text = self._extract_output_text(response)
            usage = self._usage_from_response(response)
            return LLMResult(
                model=model,
                message=AssistantPromptMessage(content=text),
                usage=usage,
            )
        except Exception as exc:
            transform = getattr(self, "_transform_invoke_error", None)
            if callable(transform):
                raise transform(exc)
            raise

    def _stream_response(
        self,
        *,
        model: str,
        response_stream: Iterable[Any],
    ) -> Generator[LLMResultChunk, None, None]:
        emitted = False
        final_usage: LLMUsage | None = None

        for event in response_stream:
            event_type = str(self._field(event, "type", ""))

            if event_type == "response.output_text.delta":
                delta = str(self._field(event, "delta", ""))
                if delta:
                    emitted = True
                    yield self._chunk(model=model, text=delta)
                continue

            if event_type == "response.output_text.done" and not emitted:
                final_text = str(self._field(event, "text", ""))
                if final_text:
                    emitted = True
                    yield self._chunk(model=model, text=final_text)
                continue

            if event_type in {"response.completed", "response.done"}:
                response_obj = self._field(event, "response")
                final_usage = self._usage_from_response(response_obj)
                break

            if event_type in {"response.failed", "error"}:
                error_obj = self._field(event, "error")
                raise RuntimeError(str(error_obj or "response stream failed"))

        yield self._chunk(
            model=model,
            text="",
            finish_reason="stop",
            usage=final_usage or self._empty_usage(),
        )

    def _chunk(
        self,
        *,
        model: str,
        text: str,
        finish_reason: str | None = None,
        usage: LLMUsage | None = None,
        index: int = 0,
    ) -> LLMResultChunk:
        return LLMResultChunk(
            model=model,
            delta=LLMResultChunkDelta(
                index=index,
                message=AssistantPromptMessage(content=text),
                usage=usage,
                finish_reason=finish_reason,
            ),
        )

    def _field(self, obj: Any, key: str, default: Any = None) -> Any:
        if obj is None:
            return default
        if isinstance(obj, Mapping):
            return obj.get(key, default)
        return getattr(obj, key, default)

    def _extract_output_text(self, response: Any) -> str:
        output_text = self._field(response, "output_text")
        if isinstance(output_text, str):
            return output_text

        output_items = self._field(response, "output", [])
        text_chunks: list[str] = []

        if not isinstance(output_items, Iterable) or isinstance(output_items, (str, bytes, bytearray)):
            return str(output_items or "")

        for item in output_items:
            content = self._field(item, "content", [])
            if not isinstance(content, Iterable) or isinstance(content, (str, bytes, bytearray)):
                if content:
                    text_chunks.append(str(content))
                continue

            for part in content:
                part_type = str(self._field(part, "type", ""))
                if part_type in {"output_text", "text"}:
                    text = self._field(part, "text", "")
                    if text:
                        text_chunks.append(str(text))

        return "".join(text_chunks)

    def _usage_from_response(self, response: Any) -> LLMUsage:
        usage_obj = self._field(response, "usage", {})
        prompt_tokens = int(self._field(usage_obj, "input_tokens", 0) or 0)
        completion_tokens = int(self._field(usage_obj, "output_tokens", 0) or 0)
        total_tokens = int(self._field(usage_obj, "total_tokens", prompt_tokens + completion_tokens) or 0)

        latency = float(getattr(self, "started_at", 0.0) or 0.0)
        return LLMUsage(
            prompt_tokens=prompt_tokens,
            prompt_unit_price=Decimal("0"),
            prompt_price_unit=Decimal("0"),
            prompt_price=Decimal("0"),
            completion_tokens=completion_tokens,
            completion_unit_price=Decimal("0"),
            completion_price_unit=Decimal("0"),
            completion_price=Decimal("0"),
            total_tokens=total_tokens,
            total_price=Decimal("0"),
            currency="USD",
            latency=latency,
        )

    def _empty_usage(self) -> LLMUsage:
        return LLMUsage(
            prompt_tokens=0,
            prompt_unit_price=Decimal("0"),
            prompt_price_unit=Decimal("0"),
            prompt_price=Decimal("0"),
            completion_tokens=0,
            completion_unit_price=Decimal("0"),
            completion_price_unit=Decimal("0"),
            completion_price=Decimal("0"),
            total_tokens=0,
            total_price=Decimal("0"),
            currency="USD",
            latency=0.0,
        )

    def get_num_tokens(
        self,
        model: str,
        credentials: dict,
        prompt_messages: list[PromptMessage],
        tools: list[PromptMessageTool] | None = None,
    ) -> int:
        del model, credentials

        plain_text = prompt_messages_to_text(prompt_messages)
        if tools:
            serialized_tools = [
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                }
                for tool in tools
            ]
            plain_text = f"{plain_text}\n{safe_json_dumps(serialized_tools)}"

        token_counter = getattr(self, "_get_num_tokens_by_gpt2", None)
        if callable(token_counter):
            return int(token_counter(plain_text))

        return len(plain_text)

    def validate_credentials(self, model: str, credentials: dict) -> None:
        try:
            client = self._new_client(credentials)
            client.responses.create(
                model=model,
                input=[{"role": "user", "content": [{"type": "input_text", "text": "ping"}]}],
                max_output_tokens=1,
                stream=False,
            )
        except Exception as exc:
            raise CredentialsValidateFailedError(str(exc)) from exc

    def get_customizable_model_schema(self, model: str, credentials: dict) -> AIModelEntity:
        del credentials

        return AIModelEntity(
            model=model,
            label=I18nObject(en_US=model, zh_Hans=model, ja_JP=model, pt_BR=model),
            model_type=ModelType.LLM,
            features=["multi-tool-call", "stream-tool-call", "agent-thought"],
            fetch_from=FetchFrom.CUSTOMIZABLE_MODEL,
            model_properties={"mode": "chat", "context_size": 128000},
            parameter_rules=[
                {"name": "temperature", "use_template": "temperature"},
                {"name": "top_p", "use_template": "top_p"},
                {"name": "max_tokens", "use_template": "max_tokens"},
                {"name": "response_format", "type": "string", "required": False},
            ],
        )
