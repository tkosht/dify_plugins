from __future__ import annotations

import logging
from collections.abc import Mapping

from ..internal.credentials import default_validation_model
from ..internal.sdk import CredentialsValidateFailedError, ModelProvider, ModelType

logger = logging.getLogger(__name__)


class OpenaiResponsesProviderModelProvider(ModelProvider):
    def validate_provider_credentials(self, credentials: Mapping) -> None:
        """Validate provider credentials by issuing a lightweight model call."""
        try:
            model_instance = self.get_model_instance(ModelType.LLM)
            model_instance.validate_credentials(
                model=default_validation_model(credentials),
                credentials=dict(credentials),
            )
        except CredentialsValidateFailedError:
            raise
        except Exception as exc:
            provider = self.get_provider_schema().provider
            logger.exception("%s credentials validate failed", provider)
            raise CredentialsValidateFailedError(str(exc)) from exc
