## OpenAI Responses Provider

Model provider plugin for Dify backed by the OpenAI Responses API.

### Features

- LLM chat invocation via `responses.create`
- Streaming delta chunk conversion
- Strict boolean coercion for model parameters (`store`, `parallel_tool_calls`)
- `response_format=json_schema` guard requiring a schema payload

### Credentials

- `openai_api_key` (required)
- `openai_organization` (optional)
- `openai_api_base` (optional, default `https://api.openai.com/v1`)

### Development

Install dependencies:

```bash
pip install -r requirements.txt
```

Run packaging:

```bash
dify plugin package app/openai_responses_provider
```
