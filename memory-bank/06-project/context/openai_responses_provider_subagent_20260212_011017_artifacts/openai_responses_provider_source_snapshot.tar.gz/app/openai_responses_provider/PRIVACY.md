## Privacy Policy

This plugin sends model inputs to the OpenAI API endpoint configured by the user.

### Data Processing

- Prompt content, optional tool definitions, and generation parameters are sent to the configured OpenAI endpoint.
- API credentials entered in Dify are used only for authentication when calling the OpenAI API.
- The plugin does not persist conversation data to local files or external storage by default.

### Data Retention

- The plugin itself does not store request or response payloads.
- Retention behavior depends on the OpenAI account policy and endpoint configuration selected by the user.

### Contact

For privacy concerns, contact the plugin maintainer through the distribution channel where this plugin is published.
